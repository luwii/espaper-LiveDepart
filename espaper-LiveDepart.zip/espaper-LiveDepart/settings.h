/**The MIT License (MIT)
Copyright (c) 2017 by Daniel Eichhorn
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
See more at http://blog.squix.ch
*/


/****************************************************************************************************************************************
 *  National Rail settings
 *  STATIONCODE, referred to as CRS code by TFL is available here https://www.nationalrail.co.uk/stations_destinations/48541.aspx
 *  https://lite.realtime.nationalrail.co.uk/OpenLDBWS/       API documentation
 *  http://nrodwiki.rockshore.net/index.php/GetArrivalBoard   SOAP example message
 *  Not sure where I got the token from, I know you need to register an account
 *  
 *****************************************************************************************************************************************/
#define STATIONCODE "YOUR_STATION"
#define TOKENCODE "YOUR_TOKENCODE"
#define NUMTRAINS_TO_RETRIEVE "4"  //Can be made more if the nrccMessage is not displayed
// ***************************************************************************************************************************************

// Language - See text.h for available text resources. 
#define LANG 'EN'

#include <simpleDSTadjust.h>
#include "text.h"

// Config mode SSID
const String CONFIG_SSID = "ESPaperConfig";

// WiFi and restart frequency
String WIFI_SSID = "YOUR_SSID";
String WIFI_PASS = "YOUR_WIFIPASSWORD";
const int UPDATE_INTERVAL_SECS = 40 * 60; // Update every 20 minutes

#define CS 15      // D8
#define RST 2      // D4
#define DC 5       // D1
#define BUSY 4     // D2
#define USR_BTN 12 // D6


#define UTC_OFFSET + 0
struct dstRule StartRule = {"CEST", Last, Sun, Mar, 2, 3600}; // UK Summer Time = UTC/GMT +1 hours (in seconds)
struct dstRule EndRule = {"CET", Last, Sun, Oct, 2, 0};       // UK Time = UTC/GMT 


// values in metric or imperial system?
bool IS_METRIC = true;

// Change for 12 Hour/ 24 hour style clock
bool IS_STYLE_12HR = false;

// change for different ntp (time servers)
#define NTP_SERVERS "0.ch.pool.ntp.org", "1.ch.pool.ntp.org", "2.ch.pool.ntp.org"


/***************************
 * End Settings
 **************************/
